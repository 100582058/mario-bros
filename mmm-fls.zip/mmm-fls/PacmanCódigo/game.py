# Miguel Moreno y Fernando Lambas
#
# Clase Game, principal de la aplicación

# Imports
import pyxel
from pacman import Pacman
from blinky import Blinky
from laberinto import Laberinto
from inky import Inky
from clyde import Clyde
from pinky import Pinky
import config

class Game:
    def __init__(self):
        pyxel.init(352, 256, title="Pac Man")
        pyxel.load("assets/resources.pyxres")

        self.game_over = False          # Estado inicial del juego
        self.collision_timer = 0        # Temporizador de retraso tras colisión
        self.level_complete_timer = 0   # Temporizador para mostrar el mensaje de nivel completado
        self.laberinto = Laberinto()    # Inicializa el laberinto
        self.reset_level()              # Resetea el nivel
        self.completado = False

        pyxel.run(self.update, self.draw)

    def reset_level(self):
        """Reinicia el nivel actual.
        Los fantasmas se inician en el centro
        Pacman en la casilla (1,1) que es la primera
        casilla libre arriva a la izquierda en todos los laberintos"""
        self.pacman = Pacman(1, 1, self.laberinto)
        self.blinky = Blinky(10, 8, self.laberinto)
        self.inky = Inky(10, 9, self.laberinto)
        self.clyde = Clyde(9, 8, self.laberinto)
        self.pinky = Pinky(9, 9, self.laberinto)

    def check_collision(self):
        """Comprueba si algún fantasma colisiona con Pac-Man usando bounding boxes,
        es decir rectángulos imaginarios para cada personaje, esto nos permite
        detectar colisiones y simplificar cálculos"""
        ghosts = [self.blinky, self.inky, self.clyde, self.pinky]

        pac_x, pac_y = self.pacman.x, self.pacman.y
        pac_w, pac_h = 10, 10   # Tamaño de Pac-Man, el tamaño real seria 16x16 pero lo bajo 
                                # para asi detectar mejor las colisiones

        for ghost in ghosts:
            ghost_x, ghost_y = ghost.x, ghost.y
            ghost_w, ghost_h = 14, 14  # Tamaño de los fantasmas, tambien un poco menores que 16x16

            # Comprobación de colisión por bounding box
            """ pac_x < ghost_x + ghost_w: El borde izquierdo de Pac-Man está a la izquierda del borde derecho del fantasma.
                pac_x + pac_w > ghost_x: El borde derecho de Pac-Man está a la derecha del borde izquierdo del fantasma.
                pac_y < ghost_y + ghost_h: El borde superior de Pac-Man está por encima del borde inferior del fantasma.
                pac_y + pac_h > ghost_y: El borde inferior de Pac-Man está por debajo del borde superior del fantasma.
            """
            if (pac_x < ghost_x + ghost_w and
                pac_x + pac_w > ghost_x and
                pac_y < ghost_y + ghost_h and
                pac_y + pac_h > ghost_y):
                # Hay colisión si todas las condiciones son true

                if config.pastilla:             # Si los fantasmas están en estado vulnerable
                    pyxel.play(0,1)             # Sonido de la segunda pista del resource.pyxes
                    config.puntos += 100        # Pac-Man gana puntos
                    ghost.reset_position()      # Reinicia al fantasma
                else:                           # Estado normal: Pacman debe morir
                    pyxel.play(0,2)             # Sonido de la tercera pista del resource.pyxres
                    config.vidas -= 1           # Le quito una vida
                    if config.vidas <= 0:       # Compruebo que le quedan vidas, si no declaro game over
                        self.game_over = True
                    else:
                        self.collision_timer = 60   # Temporizador para pausar el juego mientras muestro la pantalla
                    return                          # Salimos para evitar seguir comprobando otras colisiones

    def check_level_complete(self):
        """Verifica si se han recolectado todos los puntos."""
        for row in self.laberinto.map:
            if 0 in row or 2 in row or 3 in row:    # Si quedan puntos, frutas o pastillas no acaba el juego
                return False
        return True

    def advance_level(self):
        """Prepara el siguiente nivel."""
        self.level_complete_timer = 90      # Mostrar mensaje durante 3 segundos (90 frames)
        config.nivel += 1                   # Incrementar el nivel
        if config.nivel > 4:
            self.completado = True         # Si no hay más niveles, regresa al nivel 1
            config.nivel = 1
        if config.nivel > 1:                # Para los niveles superiores los ghost van v 2 
            config.velocidad_ghost = 2
        
        # Reducir la probabilidad de comportamiento aleatorio de los fantasmas
        """ Al subir de nivel los fantasmas se hacen más listos, es decir
            tienen menos probabilidades de comportamiento errático y por lo tanto
            van a por Pacman con más decisión, esto, la subida de velocidad y el
            incremento de las puertas en la jaula de los fantasmas es lo que 
            determinará la dificultad del juego
        """
        config.blinky_random = max(0.0, config.blinky_random - 0.05)
        config.inky_random = max(0.0, config.inky_random - 0.05)
        config.clyde_random = max(0.0, config.clyde_random - 0.05)
        config.pinky_random = max(0.0, config.pinky_random - 0.01)

    def restart_game(self):
        """Reinicia todo el juego. Se activa al pulsar R en la pantalla final"""
        config.vidas = 3
        config.puntos = 0
        config.nivel = 1
        config.velocidad_ghost = 1
        self.game_over = False
        self.completado = False
        self.collision_timer = 0
        self.level_complete_timer = 0
        self.laberinto = Laberinto()
        self.reset_level()

    def update(self):
        """Actualización del juego, siguiendo los estándares de pyxel"""
        if self.completado:
            # Esperamos a que el jugador presione R para reiniciar
            if pyxel.btnp(pyxel.KEY_R):
                self.restart_game()
            return

        if self.game_over:                                          # El juego se ha acabado, se reinicia con R
            if pyxel.btnp(pyxel.KEY_R):
                self.restart_game()
            return
        """ Si pacman colisiona con un fantasma se activa un temporizador
            que para el juego un par de segundos antes de empezar de nuevo
        """
        if self.collision_timer > 0:
            self.collision_timer -= 1
            if self.collision_timer == 0 and config.vidas > 0:  # Si aun quedan vidas se reinicia el nievel
                self.reset_level()                              # Llamo a funcion para resetear el nivel
            return
        """ Temporizador cuando se pasa el nivel mientras se muestra
            un mensaje de felicitacion que se pinta en el metodo draw
            tener en cuenta que en pyxel este metodo uddate y draw 
            ocurren cada instante por eso no necesitamos bucle
        """
        if self.level_complete_timer > 0:
            self.level_complete_timer -= 1
            if self.level_complete_timer == 0:
                self.laberinto = Laberinto()
                self.reset_level()
            return

        # Reducir temporizador de pastilla, cuando pacman se ha comido la pastilla config.pastilla = true
        if config.pastilla:
            config.pastilla_timer -= 1
            if config.pastilla_timer <= 0:
                config.pastilla = False  # Fin del estado vulnerable

        """ Actualización de Pac-Man y fantasmas, las demas clases que se dibujan no necesitan update
            porque solo se pintan y se llaman desde laberinto
        """
        self.pacman.update()
        self.blinky.update(self.pacman.x, self.pacman.y)
        self.inky.update(self.pacman.x, self.pacman.y, self.pacman.direction)
        self.clyde.update(self.pacman.x, self.pacman.y)
        self.pinky.update(self.pacman.x, self.pacman.y, self.pacman.direction)

        # Verificar colisiones entre Pac-Man y fantasmas 
        self.check_collision()

        # Verificar si se ha completado el nivel
        if self.check_level_complete():
            self.advance_level()
    
    def draw(self):
        """Dibujo de todos los elementos del juego."""
        pyxel.cls(0)  # Limpiar la pantalla

        if self.game_over:
            # Pantalla de Game Over
            pyxel.text(130, 100, "GAME OVER", pyxel.COLOR_RED)
            pyxel.text(90, 120, "PRESIONA R PARA REINICIAR", pyxel.COLOR_YELLOW)
            return

        if self.collision_timer > 0:                # Cuando existe collision se inicia el contador
            # Mostrar mensaje de colisión
            pyxel.text(130, 100, "¡NO DEJES QUE TE COMAN!", pyxel.COLOR_RED)
            return

        if self.level_complete_timer > 0:
            
            if self.completado:
                # Mostrar mensaje de juego compleatado
                pyxel.text(80, 100, "ENHORABUENA HAS COMPLETADO EL JUEGO", pyxel.COLOR_RED)
                pyxel.text(80, 130, "ERES UN CRACK DEL PACMAN", pyxel.COLOR_RED)
                pyxel.text(80, 150, "PRESIONA R PARA RECOMENZAR", pyxel.COLOR_YELLOW)
                return
                
            else:
                # Mostrar mensaje de nivel completado
                pyxel.text(50, 100, "BIEN HECHO, NIVEL COMPLETADO", pyxel.COLOR_GREEN)
                pyxel.text(80, 130, "EL PROXIMO SERA MAS DIFICIL", pyxel.COLOR_YELLOW)
                return

        

        # Dibujar laberinto, puntos, Pac-Man y fantasmas
        self.laberinto.draw()
        self.pacman.draw()
        self.blinky.draw()
        self.inky.draw()
        self.clyde.draw()
        self.pinky.draw()

        # Dibujar marcador
        pyxel.text(10, 245, f"VIDAS: {config.vidas}", 7)
        pyxel.text(100, 245, f"PUNTOS: {config.puntos}", 7)
        pyxel.text(185, 245, f"NIVEL: {config.nivel}", 7)
        pyxel.text(265, 245, "Coded by MM AND FL for UC3M",7)

# Iniciar el juego
Game()