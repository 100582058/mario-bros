# Miguel Moreno Mur
# 
# Clase Blinky: Rojo, Agresivo que persigue a Pacman
#
# Atributos:
#
# Metodos:
#

# Imports
# Imports
import random
from entidad_movible import EntidadMovible
import config
import pyxel

class Blinky(EntidadMovible):
    def __init__(self, tile_x, tile_y, laberinto):
        # Inicializamos a Blinky usando la clase base EntidadMovible
        super().__init__(tile_x, tile_y, laberinto, sprite_u=240, sprite_v=0)

    def get_random_direction(self):
        """
        Obtiene una dirección válida aleatoria.
        """
        valid_directions = self.get_valid_directions()
        if valid_directions:
            return random.choice(valid_directions)
        return self.direction

    def get_next_direction(self, pacman_x, pacman_y):
        """
        Decide la dirección óptima para acercarse a Pac-Man.
        """
        tile_pacman_x = pacman_x // self.tile_size  # Se usa para obtener el tile actual a partir de los pixeles
        tile_pacman_y = pacman_y // self.tile_size

        # Se utiliza la distancia Manhattan entre dos puntos: Distancia_Manhattan = |x2-x1|+|y2-y1|
        distances = {}
        if "RIGHT" in self.get_valid_directions():
            distances["RIGHT"] = abs(self.tile_x + 1 - tile_pacman_x) + abs(self.tile_y - tile_pacman_y)
        if "LEFT" in self.get_valid_directions():
            distances["LEFT"] = abs(self.tile_x - 1 - tile_pacman_x) + abs(self.tile_y - tile_pacman_y)
        if "UP" in self.get_valid_directions():
            distances["UP"] = abs(self.tile_x - tile_pacman_x) + abs(self.tile_y - 1 - tile_pacman_y)
        if "DOWN" in self.get_valid_directions():
            distances["DOWN"] = abs(self.tile_x - tile_pacman_x) + abs(self.tile_y + 1 - tile_pacman_y)

        if distances:
            return min(distances, key=distances.get)    # Buscamos el minimo
        return self.direction

    def reset_position(self):
        """Reinicia la posición de Blinky al inicio del laberinto."""
        self.tile_x = 10  # Posición inicial X
        self.tile_y = 8   # Posición inicial Y
        self.x = self.tile_x * self.tile_size
        self.y = self.tile_y * self.tile_size
        self.direction = "RIGHT"  # Dirección inicial

    def update(self, pacman_x, pacman_y):
        """
        Actualiza la lógica de Blinky.
        """
        # Actualiza la posición en tiles
        self.update_tile_position()

        # Si está en el centro de un tile, recalcula dirección
        if self.x % self.tile_size == 0 and self.y % self.tile_size == 0:
            if config.pastilla:  # Si Pac-Man comió una pastilla
                self.direction = self.get_random_direction()  # Mover aleatoriamente
            else:
                self.direction = self.get_next_direction(pacman_x, pacman_y)

        # Moverse en la dirección actual
        if self.direction in self.get_valid_directions():
            self.move(config.velocidad_ghost)

    def draw(self):
        """
        Dibuja a Blinky en la pantalla.
        """
        if config.pastilla:
            # Fantasma vulnerable (sprite azul)
            pyxel.blt(
                int(self.x),
                int(self.y),
                self.sprite_img,
                48,  # Coordenada U para el sprite vulnerable
                32,  # Coordenada V para el sprite vulnerable
                self.tile_size,
                self.tile_size
            )
        else:
            # Fantasma normal
            pyxel.blt(
                int(self.x),
                int(self.y),
                self.sprite_img,
                self.sprite_u,
                self.sprite_v,
                self.tile_size,
                self.tile_size
            )

