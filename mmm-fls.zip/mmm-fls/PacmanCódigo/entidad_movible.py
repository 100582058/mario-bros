# Miguel Moreno Mur
#
# Esta es la clase de la que heredan los fantasmas para los movimientos basicos
# es decir pueden atravesar paredes, puertas y no comen puntos, pastillas ni fruta
#
#Imports
import pyxel

class EntidadMovible:
    def __init__(self, tile_x, tile_y, laberinto, sprite_u, sprite_v):
        self.laberinto = laberinto
        self.tile_size = laberinto.tile_size
        # Coordenadas iniciales en tiles
        self.tile_x = tile_x                    
        self.tile_y = tile_y

        # Tamaño del tile convertido a de pixel a tile
        self.x = self.tile_x * self.tile_size
        self.y = self.tile_y * self.tile_size

        self.sprite_img = 0  # Índice del banco de sprites
        self.sprite_u = sprite_u  # Coordenada U en el sprite sheet
        self.sprite_v = sprite_v  # Coordenada V en el sprite sheet
        self.direction = "RIGHT"

    def can_move_to_tile(self, tx, ty):
        """Verifica si la entidad puede moverse a un tile específico.
            similar al de Pacman, comprueba primero que esta dentro del laberinto
            y luego que no es una pared, las puertas no nos importan aqui
        """
        if tx < 0 or tx >= self.laberinto.cols or ty < 0 or ty >= self.laberinto.rows:
            return False
        tile = self.laberinto.map[ty][tx]
        # Evitar paredes (1)
        if tile == 1:
            return False
        return True

    def get_valid_directions(self):
        """Devuelve una lista de direcciones válidas desde la posición actual."""
        valid_directions = []
        if self.can_move_to_tile(self.tile_x + 1, self.tile_y):  # Derecha
            valid_directions.append("RIGHT")
        if self.can_move_to_tile(self.tile_x - 1, self.tile_y):  # Izquierda
            valid_directions.append("LEFT")
        if self.can_move_to_tile(self.tile_x, self.tile_y - 1):  # Arriba
            valid_directions.append("UP")
        if self.can_move_to_tile(self.tile_x, self.tile_y + 1):  # Abajo
            valid_directions.append("DOWN")
        return valid_directions

    def move(self, velocidad):
        """Mueve la entidad en la dirección actual."""
        if self.direction == "RIGHT":
            self.x += velocidad
        elif self.direction == "LEFT":
            self.x -= velocidad
        elif self.direction == "UP":
            self.y -= velocidad
        elif self.direction == "DOWN":
            self.y += velocidad

    def update_tile_position(self):
        """Actualiza las coordenadas de tiles (tile_x, tile_y) según las coordenadas (x, y).
           Si la entidad está en un portal, la teletransporta al opuesto.
        """
        if self.x % self.tile_size == 0 and self.y % self.tile_size == 0:
            self.tile_x = self.x // self.tile_size
            self.tile_y = self.y // self.tile_size

            # Comprobar si es un portal (7)
            if 0 <= self.tile_y < self.laberinto.rows and 0 <= self.tile_x < self.laberinto.cols:
                tile = self.laberinto.map[self.tile_y][self.tile_x]
                if tile == 7:
                    # Portal izquierdo
                    if self.tile_x == 0 and self.tile_y == 7 and self.direction == "LEFT":
                        self.tile_x = 21
                        self.x = self.tile_x * self.tile_size
                    # Portal derecho
                    elif self.tile_x == 21 and self.tile_y == 7 and self.direction == "RIGHT":
                        self.tile_x = 0
                        self.x = self.tile_x * self.tile_size

    def draw(self):
        """Dibuja la entidad en la pantalla."""
        pyxel.blt(int(self.x), int(self.y), self.sprite_img, self.sprite_u, self.sprite_v, self.tile_size, self.tile_size)
