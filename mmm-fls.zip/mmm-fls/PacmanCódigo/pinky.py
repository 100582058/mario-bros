# Miguel Moreno Mur
#
# Clase Pinky: Intenta tender emboscada a Pac-man poniendose detras
#
# Imports
import random
from entidad_movible import EntidadMovible
import config
import pyxel

class Pinky(EntidadMovible):
    def __init__(self, tile_x, tile_y, laberinto):
        """
        Inicializa a Pinky con su posición inicial y atributos específicos.
        """
        # Llama al constructor de la clase base EntidadMovible
        super().__init__(tile_x, tile_y, laberinto, sprite_u=192, sprite_v=0)  # Sprite inicial de Pinky
        self.vulnerable_sprite_u = 48  # Coordenadas del sprite vulnerable
        self.vulnerable_sprite_v = 32
        self.is_vulnerable = False  # Estado inicial de vulnerabilidad

    def get_anticipation_direction(self, pacman_x, pacman_y, pacman_direction):
        """
        Calcula la dirección para anticipar el movimiento de Pac-Man.
        Pinky intenta ir a una posición adelantada en la dirección de Pac-Man.
        """
        # Calcular posición actual de Pac-Man en tiles
        tile_pacman_x = pacman_x // self.tile_size
        tile_pacman_y = pacman_y // self.tile_size

        # Predecir la posición futura de Pac-Man (4 tiles hacia adelante) + Distancia Manhattan
        if pacman_direction == "RIGHT":
            tile_pacman_x += 4
        elif pacman_direction == "LEFT":
            tile_pacman_x -= 4
        elif pacman_direction == "UP":
            tile_pacman_y -= 4
        elif pacman_direction == "DOWN":
            tile_pacman_y += 4

        # Calcular distancias a la posición anticipada desde las direcciones válidas usando Distancia Manhattan
        distances = {}
        if "RIGHT" in self.get_valid_directions():
            distances["RIGHT"] = abs(self.tile_x + 1 - tile_pacman_x) + abs(self.tile_y - tile_pacman_y)
        if "LEFT" in self.get_valid_directions():
            distances["LEFT"] = abs(self.tile_x - 1 - tile_pacman_x) + abs(self.tile_y - tile_pacman_y)
        if "UP" in self.get_valid_directions():
            distances["UP"] = abs(self.tile_x - tile_pacman_x) + abs(self.tile_y - 1 - tile_pacman_y)
        if "DOWN" in self.get_valid_directions():
            distances["DOWN"] = abs(self.tile_x - tile_pacman_x) + abs(self.tile_y + 1 - tile_pacman_y)

        if distances:
            return min(distances, key=distances.get) # Buscamos el minimo para acercarnos
        return self.direction

    def get_next_direction(self, pacman_x, pacman_y, pacman_direction):
        """
        Decide la dirección:
        Si está en estado vulnerable, se mueve aleatoriamente.
        95% de probabilidad de anticipar el movimiento de Pac-Man,
        5% de probabilidad de moverse aleatoriamente.
        """
        if config.pastilla:  # Si está en estado vulnerable, moverse aleatoriamente
            return random.choice(self.get_valid_directions())

        # 95% del tiempo intenta anticipar el movimiento de Pac-Man
        if random.random() < config.pinky_random:
            return random.choice(self.get_valid_directions())
        return self.get_anticipation_direction(pacman_x, pacman_y, pacman_direction)
    
    def reset_position(self):
        """Reinicia la posición de Plinky al inicio del laberinto."""
        self.tile_x = 9  # Posición inicial X
        self.tile_y = 9   # Posición inicial Y
        self.x = self.tile_x * self.tile_size
        self.y = self.tile_y * self.tile_size
        self.direction = "RIGHT"  # Dirección inicial

    def update(self, pacman_x, pacman_y, pacman_direction):
        """
        Actualiza la lógica de Pinky.
        """
        # Determina si está en estado vulnerable
        self.is_vulnerable = config.pastilla

        # Actualiza la posición en tiles
        self.update_tile_position()

        # Si está en el centro de un tile, recalcula dirección
        if self.x % self.tile_size == 0 and self.y % self.tile_size == 0:
            self.direction = self.get_next_direction(pacman_x, pacman_y, pacman_direction)

        # Moverse en la dirección actual
        if self.direction in self.get_valid_directions():
            self.move(config.velocidad_ghost)

    def draw(self):
        """Dibuja a Pinky en la pantalla."""
        if self.is_vulnerable:
            u, v = self.vulnerable_sprite_u, self.vulnerable_sprite_v
        else:
            u, v = self.sprite_u, self.sprite_v
        pyxel.blt(int(self.x), int(self.y), self.sprite_img, u, v, self.tile_size, self.tile_size)
