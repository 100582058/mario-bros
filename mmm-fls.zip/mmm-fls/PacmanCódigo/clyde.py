# Miguel Moreno Mur
#
# Clase Clyde: Fantasma Aleatorio 
#
# Atributos:
#
# Metodos:
#
# Imports
import random
from entidad_movible import EntidadMovible
import config
import pyxel

class Clyde(EntidadMovible):
    def __init__(self, tile_x, tile_y, laberinto):
        super().__init__(tile_x, tile_y, laberinto, sprite_u=208, sprite_v=0)  # Hereda de EntidadMovible
        self.vulnerable_sprite_u = 48  # Coordenadas del sprite vulnerable
        self.vulnerable_sprite_v = 32
        self.is_vulnerable = False  # Estado inicial de vulnerabilidad

    def get_collision_direction(self, pacman_x, pacman_y):
        """Calcula la dirección para intentar chocar con Pac-Man."""
         # Se utiliza la distancia Manhattan entre dos puntos: Distancia_Manhattan = |x2-x1|+|y2-y1|
         # Igual que en Blinky (comentaros alli)
        tile_pacman_x = pacman_x // self.tile_size
        tile_pacman_y = pacman_y // self.tile_size

        distances = {}
        if "RIGHT" in self.get_valid_directions():
            distances["RIGHT"] = abs(self.tile_x + 1 - tile_pacman_x) + abs(self.tile_y - tile_pacman_y)
        if "LEFT" in self.get_valid_directions():
            distances["LEFT"] = abs(self.tile_x - 1 - tile_pacman_x) + abs(self.tile_y - tile_pacman_y)
        if "UP" in self.get_valid_directions():
            distances["UP"] = abs(self.tile_x - tile_pacman_x) + abs(self.tile_y - tile_pacman_y)
        if "DOWN" in self.get_valid_directions():
            distances["DOWN"] = abs(self.tile_x - tile_pacman_x) + abs(self.tile_y + 1 - tile_pacman_y)

        if distances:
            return min(distances, key=distances.get)
        return self.direction


    def get_away_direction(self, pacman_x, pacman_y):
        """Calcula la dirección para alejarse lo máximo posible de Pac-Man.
        Se utiliza la distancia Manhattan entre dos puntos: Distancia_Manhattan = |x2-x1|+|y2-y1|
        pero en este caso se busca se aleje lo máximo posible
        # """
        tile_pacman_x = pacman_x // self.tile_size
        tile_pacman_y = pacman_y // self.tile_size

        distances = {}
        if "RIGHT" in self.get_valid_directions():
            distances["RIGHT"] = abs(self.tile_x + 1 - tile_pacman_x) + abs(self.tile_y - tile_pacman_y)
        if "LEFT" in self.get_valid_directions():
            distances["LEFT"] = abs(self.tile_x - 1 - tile_pacman_x) + abs(self.tile_y - tile_pacman_y)
        if "UP" in self.get_valid_directions():
            distances["UP"] = abs(self.tile_x - tile_pacman_x) + abs(self.tile_y - tile_pacman_y)
        if "DOWN" in self.get_valid_directions():
            distances["DOWN"] = abs(self.tile_x - tile_pacman_x) + abs(self.tile_y + 1 - tile_pacman_y)

        if distances:
            return max(distances, key=distances.get)
        return self.direction

    def get_next_direction(self, pacman_x, pacman_y):
        """
        Decide la dirección:
        Si está en estado vulnerable, se aleja de Pac-Man.
        Si no está vulnerable:
            - 85% de probabilidad de intentar colisionar con Pac-Man
            - 15% de probabilidad de intentar alejarse.
        """
        if config.pastilla:
            return self.get_away_direction(pacman_x, pacman_y)
        if random.random() < config.clyde_random:
            return self.get_collision_direction(pacman_x, pacman_y)
        else:
            return self.get_away_direction(pacman_x, pacman_y)
    
    def reset_position(self):
        """Reinicia la posición de Clydey al inicio del laberinto."""
        self.tile_x = 9  # Posición inicial X
        self.tile_y = 8   # Posición inicial Y
        self.x = self.tile_x * self.tile_size
        self.y = self.tile_y * self.tile_size
        self.direction = "RIGHT"  # Dirección inicial

    def update(self, pacman_x, pacman_y):
        """
        Actualiza la lógica de Clyde.
        """
        # Determina si está en estado vulnerable
        self.is_vulnerable = config.pastilla

        # Actualiza la posición en tiles
        self.update_tile_position()

        # Si está en el centro de un tile, recalcula dirección
        if self.x % self.tile_size == 0 and self.y % self.tile_size == 0:
            self.direction = self.get_next_direction(pacman_x, pacman_y)

        # Moverse en la dirección actual
        if self.direction in self.get_valid_directions():
            self.move(config.velocidad_ghost)

    def draw(self):
        """Dibuja a Clyde en la pantalla."""
        if self.is_vulnerable:
            u, v = self.vulnerable_sprite_u, self.vulnerable_sprite_v
        else:
            u, v = self.sprite_u, self.sprite_v
        pyxel.blt(int(self.x), int(self.y), self.sprite_img, u, v, self.tile_size, self.tile_size)