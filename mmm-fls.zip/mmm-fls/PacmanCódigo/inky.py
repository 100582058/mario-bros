# Miguel Moreno Mur
#
# Clase Inky: Patron erratico, cortando a Pacman o Retirandose
#
# Atributos:
#
# Metodos:
#
# Imports
import random
from entidad_movible import EntidadMovible
import config
import pyxel

class Inky(EntidadMovible):
    def __init__(self, tile_x, tile_y, laberinto):
        """
        Inicializa a Inky con su posición inicial y atributos específicos.
        """
        # Llama al constructor de la clase base con su posición inicial y sprite específico
        super().__init__(tile_x, tile_y, laberinto, sprite_u=224, sprite_v=0)  # Sprite inicial de Inky
        self.vulnerable_sprite_u = 48  # Coordenadas del sprite vulnerable
        self.vulnerable_sprite_v = 32
        self.is_vulnerable = False  # Estado inicial de vulnerabilidad

    def get_collision_direction(self, pacman_x, pacman_y, pacman_direction):
        """
        Calcula la dirección para intentar chocar con Pac-Man.
        Usa la posición actual de Pac-Man y su dirección para predecir un choque.
        """
        tile_pacman_x = pacman_x // self.tile_size  # Obtener la posición de Pac-Man en términos de tiles
        tile_pacman_y = pacman_y // self.tile_size

        # Predecir posición futura de Pac-Man según su dirección
        if pacman_direction == "RIGHT":
            tile_pacman_x += 1
        elif pacman_direction == "LEFT":
            tile_pacman_x -= 1
        elif pacman_direction == "UP":
            tile_pacman_y -= 1
        elif pacman_direction == "DOWN":
            tile_pacman_y += 1


         # Calcular distancias a la posición predicha en las direcciones válidas usando distancia Manhattan
        distances = {}
        if "RIGHT" in self.get_valid_directions():
            distances["RIGHT"] = abs(self.tile_x + 1 - tile_pacman_x) + abs(self.tile_y - tile_pacman_y)
        if "LEFT" in self.get_valid_directions():
            distances["LEFT"] = abs(self.tile_x - 1 - tile_pacman_x) + abs(self.tile_y - tile_pacman_y)
        if "UP" in self.get_valid_directions():
            distances["UP"] = abs(self.tile_x - tile_pacman_x) + abs(self.tile_y - 1 - tile_pacman_y)
        if "DOWN" in self.get_valid_directions():
            distances["DOWN"] = abs(self.tile_x - tile_pacman_x) + abs(self.tile_y + 1 - tile_pacman_y)

        if distances:
            return min(distances, key=distances.get)  # Buscamos el minimo para acercarnos
        return self.direction

    def get_next_direction(self, pacman_x, pacman_y, pacman_direction):
        """
        Decide la dirección para intentar chocar con Pac-Man o moverse aleatoriamente.
        Si está en estado vulnerable, se mueve aleatoriamente.
        """
        if config.pastilla:  # Si está en estado vulnerable, moverse aleatoriamente
            return random.choice(self.get_valid_directions())

        # 75% del tiempo intenta colisionar con Pac-Man, 25% se mueve aleatoriamente
        if random.random() < config.inky_random:
            return random.choice(self.get_valid_directions())
        return self.get_collision_direction(pacman_x, pacman_y, pacman_direction)

    def reset_position(self):
        """Reinicia la posición de Inky al inicio del laberinto."""
        self.tile_x = 10  # Posición inicial X
        self.tile_y = 9   # Posición inicial Y
        self.x = self.tile_x * self.tile_size
        self.y = self.tile_y * self.tile_size
        self.direction = "RIGHT"  # Dirección inicial
    def update(self, pacman_x, pacman_y, pacman_direction):
        """
        Actualiza la lógica de Inky.
        """
        # Determina si está en estado vulnerable
        self.is_vulnerable = config.pastilla

        # Actualiza la posición en tiles
        self.update_tile_position()

        # Si está en el centro de un tile, recalcula dirección
        if self.x % self.tile_size == 0 and self.y % self.tile_size == 0:
            self.direction = self.get_next_direction(pacman_x, pacman_y, pacman_direction)

        # Moverse en la dirección actual
        if self.direction in self.get_valid_directions():
            self.move(config.velocidad_ghost)

    def draw(self):
        """Dibuja a Inky en la pantalla."""
        if self.is_vulnerable:
            u, v = self.vulnerable_sprite_u, self.vulnerable_sprite_v
        else:
            u, v = self.sprite_u, self.sprite_v
        pyxel.blt(int(self.x), int(self.y), self.sprite_img, u, v, self.tile_size, self.tile_size)
