# Miguel Moreno Mur
# 
# Variables GLobales del Juego
# Config Juego
alto = 120
ancho = 160
TILE_SIZE = 8

# Estado del Juego
nivel = 1
puntos = 0
vidas = 3

# Pastilla Poder
pastilla = False
pastilla_timer = 0

# Velocidad
velocidad_ghost = 1
velocidad_pacman = 2

# Dificulad de Niveles
blinky_random = 0.01
inky_random = 0.25
clyde_random = 0.85
pinky_random = 0.05
