# Miguel Moreno Mur
#
# Clase Punto
# Metodos:
#
# Atributos:
#
# Imports
import pyxel

class Punto:
    def __init__(self, laberinto):
        self.laberinto = laberinto
        self.tile_size = laberinto.tile_size
        self.u = 32
        self.v = 112

    def draw(self):
        for row in range(self.laberinto.rows):
            for col in range(self.laberinto.cols):
                if self.laberinto.map[row][col] == 0:  # Punto
                    x = col * self.tile_size
                    y = row * self.tile_size
                    pyxel.blt(
                        x, 
                        y, 
                        0, 
                        self.u, 
                        self.v, 
                        self.tile_size, 
                        self.tile_size
                    )