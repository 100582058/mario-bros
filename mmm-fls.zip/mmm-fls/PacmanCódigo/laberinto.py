# Miguel Moreno Mur
#
# Clase Laberinto: Construye el Laberinto para cada nivel
# Metodos:
#   dibujar: Dibuja el Laberinto
#
# Atributos:
# 
#  
# Nivel: para cada nivel construye un laberinto, con estos signos
#   0: Punto
#   1: Pared
#   2: Fruta
#   3: Pastilla-Poder
#   4: Portal Izq
#   5: Vacio
#   6: Puerta
#   7: Portal Der

# Imports
import pyxel
import config                   # Config es una clase que tiene las variables globales
from puerta import Puerta       # Objeto Puerta, los fantasmaas la atraviesan, Pacman no
from punto import Punto         # El punto
from pared import Pared         # Pared del laberinto
from fruta import Fruta         # Las frutas, en este caso solo pinto fresas
from pastilla import Pastilla   # Pastilla de poder

class Laberinto:
    def __init__(self):
        self.tile_size = 16     # Tamaño del tile, es decir el cuadrado donde estan los personajes
        self.cols = 22          # de 0 a 21
        self.rows = 15          # de 0 a 14

        # Definición de laberintos con sus respectivos métodos de dibujo
        self.laberintos = [
            self.laberinto_nivel_1,
            self.laberinto_nivel_2,
            self.laberinto_nivel_3,
            self.laberinto_nivel_4,
        ]

        # Selección del laberinto según config.nivel
        self.nivel = min(config.nivel, len(self.laberintos))
        self.map = self.get_mapa()

        # Instanciar las clases que dibujan cada elemento,
        # despues las utilizaremos para pintar el laberinto
        self.punto = Punto(self)
        self.pared = Pared(self)
        self.fruta = Fruta(self)
        self.pastilla = Pastilla(self)
        self.puerta = Puerta(self)

    def get_mapa(self):
        """
        Retorna el mapa correspondiente al nivel actual.
        """
        if self.nivel == 1:
            return self.laberinto_nivel_1()
        elif self.nivel == 2:
            return self.laberinto_nivel_2()
        elif self.nivel == 3:
            return self.laberinto_nivel_3()
        elif self.nivel == 4:
            return self.laberinto_nivel_4()
        else:
            return self.laberinto_nivel_1()  # Por defecto, Nivel 1

    def laberinto_nivel_1(self):
        """
        Laberinto para el nivel 1.
        """
        return [
            [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],  # Fila 0
            [1,0,0,0,0,2,0,0,1,0,0,0,0,0,0,1,1,0,0,0,0,1],  # Fila 1
            [1,3,1,1,0,1,1,0,1,0,1,1,1,1,0,1,1,0,1,1,3,1],  # Fila 2
            [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],  # Fila 3
            [1,1,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,1,0,1],  # Fila 4
            [1,1,1,0,1,0,1,0,0,0,0,0,0,0,1,0,1,0,1,1,0,1],  # Fila 5
            [1,0,0,0,0,2,0,0,1,1,6,1,1,0,0,0,0,2,0,0,0,1],  # Fila 6
            [7,0,1,1,1,0,1,0,1,5,5,5,1,0,1,1,0,1,0,1,0,7],  # Fila 7
            [1,0,1,1,1,0,1,0,1,5,5,5,6,0,1,1,0,1,0,1,0,1],  # Fila 8
            [1,0,0,0,0,0,0,0,1,1,1,1,1,0,1,1,0,1,0,1,0,1],  # Fila 9
            [1,0,1,1,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],  # Fila 10
            [1,0,1,1,1,0,1,1,1,0,1,1,1,0,1,1,1,0,1,1,0,1],  # Fila 11
            [1,0,1,1,1,0,1,1,1,2,1,1,1,0,1,1,1,0,1,1,0,1],  # Fila 12
            [1,3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3,1],  # Fila 13
            [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]   # Fila 14
        ]

    def laberinto_nivel_2(self):
        """
        Laberinto para el nivel 2.
        """
        return [
            [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],  # Fila 0
            [1,0,0,0,0,0,0,0,1,1,0,0,0,0,0,1,1,0,0,0,0,1],  # Fila 1
            [1,3,1,1,0,1,1,0,1,1,0,1,0,1,0,1,1,0,1,1,3,1],  # Fila 2
            [1,0,1,1,0,1,1,0,0,0,0,0,0,0,0,0,0,2,0,0,0,1],  # Fila 3
            [1,0,0,0,0,0,0,0,1,1,0,1,0,1,0,1,1,0,1,1,0,1],  # Fila 4
            [1,0,1,1,0,1,1,0,0,0,0,0,0,0,0,1,1,0,1,1,0,1],  # Fila 5
            [1,0,1,1,0,1,1,0,1,1,6,1,1,0,1,1,1,0,0,0,0,1],  # Fila 6
            [7,0,0,0,0,0,0,0,1,5,5,5,1,0,0,0,0,0,1,1,0,7],  # Fila 7
            [1,0,1,1,0,1,1,0,1,5,5,5,1,0,1,1,1,1,1,1,0,1],  # Fila 8
            [1,0,1,1,0,1,1,0,1,1,6,1,1,0,1,1,1,1,1,1,0,1],  # Fila 9
            [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,1],  # Fila 10
            [1,0,1,1,0,1,1,0,1,1,0,1,1,0,1,1,0,1,1,1,0,1],  # Fila 11
            [1,3,1,1,0,1,1,2,1,1,0,1,1,0,1,1,0,1,1,1,3,1],  # Fila 12
            [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],  # Fila 13
            [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]   # Fila 14
        ]

    def laberinto_nivel_3(self):
        """
        Laberinto para el nivel 3.
        """
        return [
            [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],  # Fila 0
            [1,0,0,0,0,0,1,0,0,0,0,0,0,0,0,1,0,0,0,0,3,1],  # Fila 1
            [1,3,1,0,1,0,1,0,1,0,1,0,1,1,0,0,0,1,0,1,0,1],  # Fila 2
            [1,0,1,0,1,0,1,0,1,0,1,0,1,1,0,1,0,1,0,1,0,1],  # Fila 3
            [1,0,1,0,1,0,0,0,1,0,1,0,1,1,0,0,0,1,0,1,0,1],  # Fila 4
            [1,0,0,0,1,0,1,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1],  # Fila 5
            [1,0,1,0,0,0,1,0,1,1,6,1,1,0,1,1,0,1,0,1,0,1],  # Fila 6
            [7,0,1,0,1,0,1,0,1,5,5,5,6,2,1,1,0,1,0,1,0,7],  # Fila 7
            [1,0,1,0,1,0,0,0,6,5,5,5,1,0,0,0,0,1,0,1,0,1],  # Fila 8
            [1,0,0,0,1,0,1,0,1,1,1,6,1,1,0,1,0,0,0,0,0,1],  # Fila 9
            [1,0,1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,1,0,1,0,1],  # Fila 10
            [1,0,1,0,1,2,1,0,1,0,1,1,0,1,0,1,2,1,0,1,0,1],  # Fila 11
            [1,0,1,0,1,0,0,0,1,0,0,0,0,1,0,1,0,1,0,1,0,1],  # Fila 12
            [1,3,0,0,1,1,1,0,0,0,1,1,1,1,0,0,0,0,0,0,3,1],  # Fila 13
            [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]   # Fila 14
        ]

    def laberinto_nivel_4(self):
        """
        Laberinto para el nivel 4.
        """
        return [
            [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],  # Fila 0
            [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,0,3,1],  # Fila 1
            [1,3,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,1],  # Fila 2
            [1,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,3,1],  # Fila 3
            [1,0,0,0,0,2,0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,1],  # Fila 4
            [1,3,0,0,0,0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,3,1],  # Fila 5
            [1,0,0,0,0,0,0,2,1,1,6,1,1,2,0,0,0,0,0,0,0,1],  # Fila 6
            [7,0,0,0,0,0,0,0,6,5,5,5,1,0,0,0,0,0,0,0,3,7],  # Fila 7
            [1,3,0,2,0,2,0,2,1,5,5,5,6,2,0,2,0,2,0,2,0,1],  # Fila 8
            [1,0,0,0,0,0,0,0,1,1,6,1,1,0,0,0,0,0,0,0,3,1],  # Fila 9
            [1,0,0,0,0,0,0,2,0,0,0,0,0,2,0,0,0,0,0,0,0,1],  # Fila 10
            [1,3,0,0,0,0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,3,1],  # Fila 11
            [1,0,0,0,0,2,0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,1],  # Fila 12
            [1,3,0,0,2,0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,3,1],  # Fila 13
            [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]   # Fila 14
        ]

    def draw(self):
        # Llamamos al draw de cada clase objeto para pintar cada
        # sprite en el laberinto
        self.pared.draw()
        self.fruta.draw()
        self.pastilla.draw()
        self.puerta.draw()
        self.punto.draw()

        # No dibujamos vacio (5) ni portal (7)
