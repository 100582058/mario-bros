# Miguel Moreno Mur
#
# Clase Pastilla de Poder
# Metodos:
#
# Atributos:
#
# Imports
import pyxel

class Fruta:
    def __init__(self, laberinto):
        self.laberinto = laberinto
        self.tile_size = laberinto.tile_size
        # Coordenadas del sprite de la fruta (tomadas del código original)
        self.u = 96
        self.v = 16

    def draw(self):
        for row in range(self.laberinto.rows):
            for col in range(self.laberinto.cols):
                if self.laberinto.map[row][col] == 2:  # Fruta
                    x = col * self.tile_size
                    y = row * self.tile_size
                    pyxel.blt(
                        x,
                        y,
                        0,
                        self.u,
                        self.v,
                        self.tile_size,
                        self.tile_size,
                    )