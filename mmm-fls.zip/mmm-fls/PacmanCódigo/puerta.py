# Miguel Moreno Mur
#
# Clase PuertaPunto
# Metodos:
#
# Atributos:
#
# Imports
import pyxel

class Puerta:
    def __init__(self, laberinto):
        self.laberinto = laberinto
        self.tile_size = laberinto.tile_size
        # Coordenadas del sprite de la puerta
        self.u = 64
        self.v = 112

    def draw(self):
        for row in range(self.laberinto.rows):
            for col in range(self.laberinto.cols):
                if self.laberinto.map[row][col] == 6:  # Puerta
                    x = col * self.tile_size
                    y = row * self.tile_size
                    pyxel.blt(
                        x,
                        y,
                        0,
                        self.u,
                        self.v,
                        self.tile_size,
                        self.tile_size,
                    )