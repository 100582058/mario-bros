# Miguel Moreno Mur
#
# Clase Pacman: Controla la logica, movimiento y la visualizacion de pacman

import pyxel
import config

class Pacman:
    def __init__(self, tile_x, tile_y, laberinto):
        self.laberinto = laberinto                  # Objeto Laberinto
        self.tile_size = laberinto.tile_size
        self.tile_x = tile_x                        # Posición inicial x del pacman
        self.tile_y = tile_y                        # Posición inicial y del pacman
        self.x = self.tile_x * self.tile_size       # Tamaño del tile, se convierte de pixel a tiles multiplicando
        self.y = self.tile_y * self.tile_size

        self.w = 16                                 # Ancho del sprite
        self.h = 16                                 # Alto del sprite
        self.sprite_img = 0                         # Banco de sprites a usar

        self.direction = "RIGHT"                    # Dirección inicial a la derecha
        self.next_direction = None                  # Dirección que el jugador quiere ir, al inicio 0
        self.mouth_open = True                      # Variable para elegir qué imagen pintar, si boca abierta o muy abierta

        pyxel.load("assets/resources.pyxres")       # Cargar el archivo de recursos con imagenes y sonidos

    def can_move_to_tile(self, tx, ty):
        """Verifica si Pac-Man puede moverse a un tile."""
        if tx < 0 or tx >= self.laberinto.cols or ty < 0 or ty >= self.laberinto.rows:
            return False                        # Está fuera de los limites
        tile = self.laberinto.map[ty][tx]       # Obtener el valor del tile
        if tile == 1 or tile == 6:              # Pared o puerta, Pacman no puede pasar
            return False
        return True

    def can_move_in_direction(self, direction, tile_x, tile_y):
        """Si puede moverse movemos seguin el cursor"""
        if direction == "RIGHT":
            tile_x += 1
        elif direction == "LEFT":
            tile_x -= 1
        elif direction == "UP":
            tile_y -= 1
        elif direction == "DOWN":
            tile_y += 1
        return self.can_move_to_tile(tile_x, tile_y)

    def move_pacman(self, direction, velocidad):
        """Mueve a Pacman en la dirección indicada"""
        if direction == "RIGHT":
            self.x += velocidad
        elif direction == "LEFT":
            self.x -= velocidad
        elif direction == "UP":
            self.y -= velocidad
        elif direction == "DOWN":
            self.y += velocidad

    def update(self):
        velocidad = config.velocidad_pacman  # Velocidad desde config

        # Detección de entrada de dirección
        """Aqui se lee el input del jugador, para saber cual sera la proxima
        dirección a la que tenemos que ir
        """
        if pyxel.btnp(pyxel.KEY_RIGHT):
            self.next_direction = "RIGHT"
        elif pyxel.btnp(pyxel.KEY_LEFT):
            self.next_direction = "LEFT"
        elif pyxel.btnp(pyxel.KEY_UP):
            self.next_direction = "UP"
        elif pyxel.btnp(pyxel.KEY_DOWN):
            self.next_direction = "DOWN"
        
        """ Para alinear a pacman en un tile
        """
        aligned_x = (self.x % self.tile_size == 0)
        aligned_y = (self.y % self.tile_size == 0)

        if aligned_x and aligned_y:
            # Centrados en un tile, la división tiene que ser entera
            self.tile_x = self.x // self.tile_size
            self.tile_y = self.y // self.tile_size

            # Comprobar si es un portal
            if 0 <= self.tile_y < self.laberinto.rows and 0 <= self.tile_x < self.laberinto.cols:
                current_tile = self.laberinto.map[self.tile_y][self.tile_x]

                # Si es un portal (7) verificamos teletransportacion, en los dos portales
                if current_tile == 7:
                    # Portal izquierdo
                    if self.tile_x == 0 and self.tile_y == 7 and self.direction == "LEFT":
                        self.tile_x = 21
                        self.x = self.tile_x * self.tile_size
                    # Portal derecho
                    elif self.tile_x == 21 and self.tile_y == 7 and self.direction == "RIGHT":
                        self.tile_x = 0
                        self.x = self.tile_x * self.tile_size

                    # Después de teletransportar, no nos detenemos, seguimos con la lógica normal

                # Comer ítems, bien punto, pastilla o fruta
                if current_tile == 0:
                    config.puntos += 1
                    pyxel.play(0,0)        # Sonido de comer punto pista 0                         
                    self.laberinto.map[self.tile_y][self.tile_x] = 5
                elif current_tile == 2:
                    config.puntos += 20
                    pyxel.play(0,1)         # Sonido pista 1
                    self.laberinto.map[self.tile_y][self.tile_x] = 5
                elif current_tile == 3:
                    config.pastilla = True
                    config.pastilla_timer = 8 * 30  # Cuenta atras de 8 segundos en los que los fantasmas son vulnerables
                    pyxel.play(0,1)                 # Sonido pista 1
                    self.laberinto.map[self.tile_y][self.tile_x] = 5 # Limpiar y dibujar luego un vacio

            # Intentar cambiar dirección, si puede moverse
            if self.next_direction and self.can_move_in_direction(self.next_direction, self.tile_x, self.tile_y):
                self.direction = self.next_direction
                self.next_direction = None
                self.mouth_open = True
            else:
                # Mantener dirección actual
                if not self.can_move_in_direction(self.direction, self.tile_x, self.tile_y):
                    # No podemos movernos
                    return

            # Alternar la boca de Pac-Man, utilizo una negacion que cambia entre true y false
            self.mouth_open = not self.mouth_open

        # Intentar mover a Pac-Man en la dirección actual
        if self.can_move_in_direction(self.direction, self.tile_x, self.tile_y):
            self.move_pacman(self.direction, velocidad)

            # Comprobar de nuevo el portal después de mover (normalmente innecesario, pero por seguridad)
            aligned_x = (self.x % self.tile_size == 0)
            aligned_y = (self.y % self.tile_size == 0)
            if aligned_x and aligned_y:
                self.tile_x = self.x // self.tile_size
                self.tile_y = self.y // self.tile_size
                if 0 <= self.tile_y < self.laberinto.rows and 0 <= self.tile_x < self.laberinto.cols:
                    if self.laberinto.map[self.tile_y][self.tile_x] == 7:
                        if self.tile_x == 0 and self.tile_y == 7 and self.direction == "LEFT":
                            self.tile_x = 21
                            self.x = self.tile_x * self.tile_size
                        elif self.tile_x == 21 and self.tile_y == 7 and self.direction == "RIGHT":
                            self.tile_x = 0
                            self.x = self.tile_x * self.tile_size

        if pyxel.btnp(pyxel.KEY_Q):
            pyxel.quit()        # Habilito salir de juego con la tecla Q
        
        # Hack para aumentar de vidas con la tecla v
        # Solo funcionará si Pacman se está moviendo
        if pyxel.btnp(pyxel.KEY_V):
            config.vidas += 1

    def draw(self):
        # Seleccionar sprite según la dirección de Pac-Man
        if self.direction == "RIGHT":
            u, v = (160,16) if self.mouth_open else (160,32)
        elif self.direction == "LEFT":
            u, v = (144,16) if self.mouth_open else (144,32)
        elif self.direction == "UP":
            u, v = (128,16) if self.mouth_open else (128,32)
        else:  # DOWN
            u, v = (160,64) if self.mouth_open else (160,80)

        pyxel.blt(int(self.x), int(self.y), self.sprite_img, u, v, self.w, self.h)




