# Miguel Moreno Mur

import pyxel

class Pared:
    def __init__(self, laberinto):
        self.laberinto = laberinto
        self.tile_size = laberinto.tile_size

        # Coordenadas del sprite para las paredes 
        self.wall_u = 16
        self.wall_v = 112

    def draw(self):
        for row in range(self.laberinto.rows):
            for col in range(self.laberinto.cols):
                if self.laberinto.map[row][col] == 1:  # Pared
                    x = col * self.tile_size
                    y = row * self.tile_size
                    pyxel.blt(
                        x,
                        y,
                        0,
                        self.wall_u,
                        self.wall_v,
                        self.tile_size,
                        self.tile_size,
                    )