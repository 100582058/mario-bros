WIDTH, HEIGHT = 700, 500
# Las posiciones en las que puede estar un paquete en la cinta (columnas de la matriz)
POSICIONES_PAQUETES_CINTA = 8
DIFICULTAD = "facil"
NUM_CINTAS = 5  # Depende de la dificultad
# ?Separación entre cintas
SEP_ENTRE_CINTAS = 40
TIEMPO, VIDAS = 0, 0
# NUM_CINTAS, TIEMPO, VIDAS = asignarValores(DIFICULTAD)
